// 하단 콤보박스
import React from 'react';
// 콤보박스 데이터 불러오기
import comboData from "../data/combo_data.js";

function ComboBox(props) {
     
    return (
        <div>
            <button>Fa</button>
        </div>
    );
}

export default ComboBox;