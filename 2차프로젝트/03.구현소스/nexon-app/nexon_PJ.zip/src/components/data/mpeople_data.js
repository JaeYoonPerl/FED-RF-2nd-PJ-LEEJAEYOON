
export const mainPeople={
    tit: "PEOPLE",
    txt: "도전과 변화를 즐기는 모험가들이 재미의 진화를 이끌어갑니다.",
    link: "/people",
}

