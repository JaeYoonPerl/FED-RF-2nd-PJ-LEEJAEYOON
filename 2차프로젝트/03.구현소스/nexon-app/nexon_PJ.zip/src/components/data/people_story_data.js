// 넥슨인 이야기 데이터
export const poepleStoryData =[
    {
        stit:"무슨 회사에서 일하세요?",
        simg:"https://dszw1qtcnsa5e.cloudfront.net/community/20240112/b562a4fa-9157-4fe9-98d6-db83b1b112c0/%ED%99%88%ED%8E%98%EC%9D%B4%EC%A7%80%ED%94%BC%ED%94%8C%EB%B0%B0%EB%84%88.png",
        slink:"https://blog.nexon.com/post/2208754"

    },
    {
        stit:"우리는 모두 유저였다",
        simg:"https://dszw1qtcnsa5e.cloudfront.net/community/20231004/e2f2fd31-7001-4fda-b329-e17386f93270/%EC%9C%A0%EC%A0%80.jpg",
        slink:"https://blog.nexon.com/post/2260391"

    },
    {
        stit:"나의 판교 입성기",
        simg:"https://dszw1qtcnsa5e.cloudfront.net/community/20231004/cfb01a17-6789-49ef-a405-538671bf2f89/%ED%8C%90%EA%B5%90%EC%9E%85%EC%84%B1%EA%B8%B0.jpg",
        slink:"https://blog.nexon.com/post/2296271"

    },
    {
        stit:"오늘도 아이와 출근합니다",
        simg:"https://dszw1qtcnsa5e.cloudfront.net/community/20240409/00ca5157-59be-4e87-8b03-30b1078b798b/%EA%B8%B0%EC%97%85%EC%82%AC%EC%9D%B4%ED%8A%B8%EB%8F%84%ED%86%A0%EB%A6%AC%EC%86%8C%ED%92%8D.jpg",
        slink:"https://blog.nexon.com/post/2542920"

    },
    {
        stit:"게임이 음악이 될 때",
        simg:"https://dszw1qtcnsa5e.cloudfront.net/community/20240112/4ad3f43d-0b47-439f-9030-c0b5330da21f/MicrosoftTeamsimage29.png",
        slink:"https://blog.nexon.com/post/2446444"

    },
]

export const nexonTag ={
    nTimg:"/images/nexon_tag_people.png"
}