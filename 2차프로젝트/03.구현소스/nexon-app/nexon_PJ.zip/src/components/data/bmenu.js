// 하단 링크 정보

export const bmData = [
    {
        txt:"개인정보처리방침",
        link:"https://company.nexon.com/ko/privacy-policy",
    },
    {
        txt:"CONTACT US",
        link:"https://company.nexon.com/ko/contact-us",
    },
    {
        txt:"LOCATIONS",
        link:"",
    },
    {
        txt:"윤리경영",
        link:"https://company.nexon.com/ko/ethical-management",
    },
    {
        txt:"공고",
        link:"https://company.nexon.com/ko/announcement",
    },
    {
        txt:"IR",
        link:"https://ir.nexon.co.jp/kr/",
    },
];