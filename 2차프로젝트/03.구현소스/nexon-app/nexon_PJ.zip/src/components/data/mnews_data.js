export const mainNews={
    
        tit: "NEWS",
        
        link: "/news",
    
}