export const peopleLifeSw =[
    {
        tit:"넥슨 코리아 사옥 로비",
        isrc:"https://company.nexon.com/assets/people-slider-1-ce905081.png",
    },
    {
        tit:"사내식당 Dining N",
        isrc:"https://company.nexon.com/assets/people-slider-2-f36aaaef.png",
    },
    {
        tit:"직원휴식공간 BETWEEN",
        isrc:"https://company.nexon.com/assets/people-slider-3-f0821767.png",
    },
    {
        tit:"사내카페 넥슨다방",
        isrc:"https://company.nexon.com/assets/people-slider-4-ad965ad0.png",
    },
    {
        tit:"피트니스 Level Up",
        isrc:"https://company.nexon.com/assets/people-slider-5-3f7b0225.png",
    },
    {
        tit:"내마음읽기 상담실",
        isrc:"https://company.nexon.com/assets/people-slider-7-34e0fd61.png",
    },
    {
        tit:"도토리소풍 넥슨 별 어린이집",
        isrc:"https://company.nexon.com/assets/people-slider-8-742db708.png",
    },
    {
        tit:"영상&사운드 스튜디오",
        isrc:"https://company.nexon.com/assets/people-slider-10-448eb934.png",
    },
]