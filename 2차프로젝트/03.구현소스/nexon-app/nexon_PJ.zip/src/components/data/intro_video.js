// 이미지 경로 정보
export const ivideo = {

    //  메인영상 
    mainv: "/videos/main_video.mp4",
    // company영상
    companyv: "/videos/company_video.mp4",
    // business영상1
    gamev01: "/videos/business_video01.mp4",
    // business영상2
    gamev02: "/videos/business_video02.mp4",
    
};