// 이미지 경로 정보
export const isrc = {


    // 상단 로고
    logo: "/images/logo_w.png",

    // 하단 로고
    footlogo: "https://i.namu.wiki/i/PZDFm5974yciyLBkz3viarpVMLiOdE7BBmuYWbSl3HA7uJgPS3pmeJpD2UM7PLn9Ty6Rqpve-3tvadj1IPBS6g.svg"

};