export const subPgIntro={
   company:{
            tit:"COMPANY",
            isrc:"https://company.nexon.com/images/company-background.jpg"
   },
    game:{
             tit:"GAME",
            isrc:"https://company.nexon.com/images/business/business_video_first_frame.jpg",
            
    },
    people:{
             tit:"PEOPLE",
             isrc:"https://company.nexon.com/assets/people-background-1920-ebf61a09.png",
    },
    news:{
             tit:"NEWS",
            isrc:"https://company.nexon.com/images/news/news-background-1024.png"
    }

};

