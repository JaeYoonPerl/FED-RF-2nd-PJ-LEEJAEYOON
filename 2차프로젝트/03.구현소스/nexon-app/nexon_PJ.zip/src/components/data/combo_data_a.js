// 하단 콤보박스 바인딩 데이터 
export const comboDataA=[
    {
        brand:"넥슨 게임 포털↗",
        brandLink:"https://www.nexon.com/Home/Game"
    },

    {
        brand:"넥슨컴퍼니 채용↗",
        brandLink:"https://career.nexon.com/common/main",
    },
    {
        brand:"넥슨태그↗",
        brandLink:"https://blog.nexon.com/",
    },
    {
        brand:"넥슨재단↗",
        brandLink:"https://nexonfoundation.org/ko",
    },
    {
        brand:"넥슨컴퓨터박물관↗",
        brandLink:"https://computermuseum.nexon.com/",
    },
    {
        brand:"인텔리전스랩스 테크블로그↗",
        brandLink:"https://www.intelligencelabs.tech/"
    },
    
    
];

