// 회사 페이지 컴포넌트 ///



export default function Company(){
    // 코드 리턴구역 ////
    return(
        <>
           
           <h1>컴퍼니페이지</h1>
        </>
    );
} /////// Company /////